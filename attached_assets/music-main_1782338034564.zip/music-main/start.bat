@echo off
title CYBORG Music Selfbot
cd /d "%~dp0"
python main.py
pause
