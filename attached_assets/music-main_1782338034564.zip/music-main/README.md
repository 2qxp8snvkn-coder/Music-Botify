<div align="center">

# CYBORG Music

### `Discord Music Selfbot • Multi-Bot • Lavalink Powered`

A high-performance Discord music selfbot with multi-account support, 6 streaming sources, 15+ audio filters, Hindi TTS, and a powerful interactive CLI — all controlled from your terminal.

[![GitHub](https://img.shields.io/badge/GitHub-ItzYourHacker-181717?style=for-the-badge&logo=github&logoColor=white)](https://github.com/ItzYourHacker)
[![Python](https://img.shields.io/badge/Python-3.10+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://python.org)
[![Discord](https://img.shields.io/badge/discord.py--self-2.0+-5865F2?style=for-the-badge&logo=discord&logoColor=white)](https://github.com/dolfies/discord.py-self)
[![Lavalink](https://img.shields.io/badge/Lavalink-5.0+-FF6B6B?style=for-the-badge&logo=apache&logoColor=white)](https://github.com/lavalink-devs/Lavalink)

</div>

---

## Features

<table>
<tr>
<td width="50%">

### Music Playback
Full-featured playback engine powered by Lavalink.

- Search & play from **6 streaming sources**
- Smart **multi-source search** with auto-scoring
- Playlist support (load entire playlists at once)
- Volume control from **1 to 1000**
- Seek to any position in a track
- Toggle pause / resume instantly
- Auto-skip on stuck or errored tracks

</td>
<td width="50%">

### Multi-Bot Support
Run multiple selfbot accounts simultaneously.

- Load **any number of tokens** from `tokens.txt`
- All bots receive commands **simultaneously**
- **Synchronized playback** start across all bots
- Auto-removes invalid/expired tokens
- Per-bot context — set different guilds/VCs
- Live bot list with guild count & node info

</td>
</tr>
<tr>
<td width="50%">

### Audio Filters (15+)
Real-time audio processing via Lavalink filters.

| Filter | Effect |
|---|---|
| `nightcore` | Speed + pitch up |
| `lofi` | Chill slowed vibe |
| `bassboost` | Enhanced low-end |
| `8d` | 3D rotating audio |
| `slowmo` | Slowed + pitched |
| `chipmunk` | High-pitch fast |
| `darthvader` | Deep dark voice |
| `earrape` | Max distortion |
| `tremolo` | Wavering effect |
| `vibrate` | Tremolo + vibrato |
| `daycore` | Slightly slower |
| `damon` | Ultra slowed |
| `dis` / `loud` / `121` | Custom FX |

</td>
<td width="50%">

### Hindi TTS
Speak text aloud in voice channels using Edge TTS.

- Two voice options: **Swara** & **Madhur**
- Plays directly into the active voice channel
- Switch voices on the fly with `ttsvoice`
- Stop TTS cleanly with `ttsstop`

### Queue Management
Full control over the playback queue.

- **Shuffle** the entire queue randomly
- **Loop** a single track or the full queue
- **Clear** the queue at any time
- **Replay** — push current track back to #1
- View queue with track durations (up to 20 shown)

### Session Control
Manage guilds and presence from the CLI.

- `use <guild_id> [vc_id]` — set active context
- Switch bot presence: `online` / `idle` / `dnd` / `invisible`
- View all connected guilds with member counts
- Check Lavalink node connection status live

</td>
</tr>
</table>

---

## Streaming Sources

| Prefix | Source | Example |
|---|---|---|
| `sp ` | Spotify | `play sp shape of you` |
| `yt ` | YouTube | `play yt lofi beats` |
| `sc ` | SoundCloud | `play sc phonk remix` |
| `js ` | JioSaavn | `play js arijit singh` |
| `am ` | Apple Music | `play am blinding lights` |
| `dz ` | Deezer | `play dz tame impala` |
| *(none)* | Auto (best match) | `play shape of you` |

Direct URLs from any supported platform are also accepted.

---

## Setup

### Prerequisites

- Python **3.10+**
- A running **Lavalink v4/v5** server
- One or more Discord **user tokens**

### Installation

```bash
# 1. Clone the repository
git clone https://github.com/ItzYourHacker/music.git
cd cyborg-music

# 2. Install dependencies
pip install -r requirements.txt

# 3. Add your tokens (one per line)
echo "YOUR_TOKEN_HERE" > tokens.txt

# 4. Configure your Lavalink node
# Edit config.json (see below)

# 5. Run
python main.py
# OR on Windows:
start.bat
```

### `config.json`

```json
{
    "nodes": [
        {
            "name": "main",
            "host": "your.lavalink.host",
            "port": 2333,
            "auth": "youshallnotpass",
            "secure": false
        }
    ]
}
```

> You can add multiple nodes under the `"nodes"` array for load balancing or failover.

### `tokens.txt`

```
TOKEN_ONE
TOKEN_TWO
TOKEN_THREE
```

Each line is a separate Discord user token. Invalid tokens are automatically detected and removed at startup.

---

## CLI Commands

Once running, control everything from the interactive `cyborg >` prompt.

### Music

| Command | Description |
|---|---|
| `join` | Join the configured voice channel |
| `play <query/url>` | Play a song or playlist |
| `skip` | Skip the current track |
| `stop` | Stop and clear the queue |
| `dc` | Disconnect from voice |
| `np` | Show now playing with progress bar |
| `queue` | Display the current queue |
| `volume [1-1000]` | Get or set volume |
| `seek <seconds>` | Seek to a position |
| `pause` | Toggle pause / resume |

### Queue

| Command | Description |
|---|---|
| `shuffle` | Shuffle the queue randomly |
| `loop <track/queue/off>` | Set loop mode |
| `clear` | Clear the queue |
| `replay` | Push current track to queue #1 |

### Filters

| Command | Description |
|---|---|
| `filter <name>` | Apply an audio filter |
| `filter clear` | Remove all active filters |
| `filters` | List all available filters |

### Hindi TTS

| Command | Description |
|---|---|
| `tts <text>` | Speak text in voice channel |
| `ttsvoice <swara/madhur>` | Switch TTS voice |
| `ttsstop` | Stop TTS and disconnect |
| `ttsvoices` | List available TTS voices |

### Session

| Command | Description |
|---|---|
| `use <guild_id> [vc_id]` | Set active guild & voice channel |
| `bots` | List all loaded bots |
| `guilds` | List all guilds |
| `nodes` | Show Lavalink node status |
| `status <online/idle/dnd>` | Change bot presence |
| `help` | Show all commands |
| `exit` | Shut down cleanly |

---

## Project Structure

```
cyborg-music/
├── main.py           # Entry point — loads tokens, starts bots
├── config.json       # Lavalink node configuration
├── tokens.txt        # Discord user tokens (one per line)
├── requirements.txt  # Python dependencies
├── start.bat         # Windows quick-start script
└── core/
    ├── player.py     # PlayerManager — Lavalink playback engine
    ├── cli.py        # Interactive terminal command interface
    ├── filters.py    # 15+ audio filter definitions
    ├── tts.py        # Hindi TTS via edge-tts
    ├── voice.py      # Lavalink voice client adapter
    ├── logger.py     # Colored console logger
    └── utils.py      # Helpers: formatting, progress bar, banner
```

---

## Tech Stack

![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![discord.py-self](https://img.shields.io/badge/discord.py--self-5865F2?style=for-the-badge&logo=discord&logoColor=white)
![Lavalink](https://img.shields.io/badge/Lavalink-FF6B6B?style=for-the-badge&logo=apache&logoColor=white)
![aiohttp](https://img.shields.io/badge/aiohttp-2C5BB4?style=for-the-badge&logo=aiohttp&logoColor=white)
![Edge TTS](https://img.shields.io/badge/Edge_TTS-0078D4?style=for-the-badge&logo=microsoftedge&logoColor=white)

---

## Disclaimer

This project is a **selfbot** — it automates a real Discord user account. Usage of selfbots **violates Discord's Terms of Service**. This is intended for **educational and personal use only**. Use at your own risk.

---

<div align="center">

### Made by MoHiT

[![Portfolio](https://img.shields.io/badge/notherhacker.space-blueviolet?style=flat-square&logo=googlechrome&logoColor=white)](https://notherhacker.space/)
[![Discord](https://img.shields.io/badge/Discord-5865F2?style=flat-square&logo=discord&logoColor=white)](https://discord.com/users/148293714010177536)
[![GitHub](https://img.shields.io/badge/GitHub-181717?style=flat-square&logo=github&logoColor=white)](https://github.com/ItzYourHacker)

</div>
